namespace Application.DTOs.Stages;

public class CreateStageRequest
{
    public string Name { get; set; } = string.Empty;

    public string? Description { get; set; }

    public int Order { get; set; }
}
